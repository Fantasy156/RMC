Project_dir=${1}				#工程目录 (传递参数不可修改)
Plus_file=$(readlink -f "$0")   #插件运行文件
Plug_dir=$(dirname ${Plus_file})  #插件目录



printf "工程目录 ${Project_dir}\n"
printf "插件运行文件 ${Plus_file}\n"
printf "插件目录 ${Plug_dir}\n"

read -p "按任意键退出" aaa