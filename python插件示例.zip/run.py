#!/usr/bin/env python3
# -*-coding:utf-8-*-
import sys
from pathlib import Path

#工程目录 (参数传递)
Project_dir = sys.argv[1]
#插件目录
Plug_dir = str(Path(__file__).parent.absolute())
#插件运行文件(run.py)
Plug_file = str(Path(__file__).absolute())

def main():
  print('工程目录', Project_dir)
  print('插件目录', Plug_dir)
  print('插件运行文件', Plug_file)
  
if __name__ == '__main__':
  main()
  input('按任意键退出')
  